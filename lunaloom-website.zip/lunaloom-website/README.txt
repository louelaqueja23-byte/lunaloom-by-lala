LUNALOOM BY LALA — WEBSITE FILES

WHAT'S INCLUDED
- index.html: responsive landing page
- assets/lunaloom-logo.png: generated brand logo
- assets/pajama-collection.png: generated five-pajama product image

BEFORE PUBLISHING
1. Create or open your Facebook business page.
2. Find your page username. Your Messenger link should look like:
   https://m.me/YourPageUsername
3. Open index.html in a text editor and replace every occurrence of:
   https://m.me/YourPageUsername
   with your real Messenger URL.
4. Update the product names, prices, descriptions, and availability to match your actual products. The current prices intentionally say “Price coming soon.”
5. Save the file.

PREVIEW ON YOUR COMPUTER
- Keep index.html and the assets folder together.
- Double-click index.html to open it in a web browser.

FREE BEGINNER-FRIENDLY PUBLISHING OPTION: GITHUB PAGES
1. Sign up or sign in at https://github.com/.
2. Create a new public repository, for example: lunaloom-by-lala.
3. Upload index.html and the entire assets folder (including both images) to the repository's main/root folder.
4. Open the repository's Settings → Pages.
5. Under Build and deployment, choose “Deploy from a branch,” select the main branch and /(root), then Save.
6. Wait a few minutes. GitHub Pages will show the published website URL in Settings → Pages.
7. Open that URL on your phone and test all Messenger links.

OTHER SIMPLE OPTION
Netlify also offers website deployment: https://www.netlify.com/ . You can create a site by uploading the website folder through its manual deploy flow. Keep the index.html file at the top level and include the assets folder.

IMPORTANT NOTES
- This is a static landing page, not a full shopping cart or payment system.
- Messenger links will not work correctly until you replace the placeholder with your real Facebook Page username/link.
- This site does not collect customer information or process payments.
- Product cards use the same generated collection photo with different crops as temporary visuals. Replace these with clear individual photos of your actual products for a more accurate shop display.
